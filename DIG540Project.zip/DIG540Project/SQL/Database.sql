CREATE TABLE `ajccom_curating_student`.`album_genre` ( `album_id` INT NOT NULL , `genre_id` INT NOT NULL ) ENGINE = InnoDB;

CREATE TABLE `ajccom_curating_student`.`genre` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `ajccom_curating_student`.`album` (
    `id` INT NOT NULL AUTO_INCREMENT ,
    `artist` VARCHAR(255) NOT NULL ,
    `title` VARCHAR(255) NOT NULL ,
    `album` VARCHAR(255) NOT NULL ,
    `year` INT NOT NULL ,
    `sub_genre` VARCHAR(255) NOT NULL ,
    `composer` VARCHAR(255) NOT NULL ,
    `image_name` VARCHAR(255) NOT NULL ,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;
