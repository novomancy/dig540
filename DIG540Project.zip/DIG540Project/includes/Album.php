<?php
class Album{
    private $artist;
    private $title;
    private $album;
    private $year;
    private $genre;
    private $sub_genre;
    private $composer;
    private $image_name;

    public function setID($dbID){ $this->id = $dbID; }
    public function setArtist($artistName){ $this->artist = $artistName; }
    public function getArtist(){ print_r( 'Artist: '.$this->artist . '<br>'); }
    public function setTitle($titleName){ $this->title = $titleName; }
    public function getTitle(){ print_r('Title: '.$this->title . '<br>'); }
    public function setAlbum($albumName){ $this->album = $albumName; }
    public function getAlbum(){ print_r('Album: '.$this->album . '<br>'); }
    public function setYear($year){ $this->year = $year; }
    public function getYear(){ print_r('Year: '.$this->year . '<br>'); }
    public function setImageName($image_name){ $this->image_name = $image_name; }
    public function getImageName(){ print_r('<img src="images/' . $this->image_name . '" alt="Album Image" height="300">'); }


    public function setGenre($genre){

        $this->genre = str_getcsv($genre);


    }
    public function getGenre(){
        for($j=0; $j<count($this->genre); $j++){
            print_r('<a href="list_albums.php?genre='.$this->genre[$j].'">Genre #'.($j+1).' is '.$this->genre[$j].'</a><br>');
        }
    }
    
    public function setSubgenres($subs){
        $this->sub_genre = str_getcsv($subs);
    }
    public function getSubgenres(){
        for($j=0; $j<count($this->sub_genre); $j++){
            print_r("Subgenre #".($j+1)." is ".$this->sub_genre[$j]."<br>");
        }
    }
    public function getAlbumLink(){
        $anchor = '<a href="show_album.php?id='.$this->id.'">'.$this->album.'</a>';
        print_r( $anchor . ' by ' . $this->artist . '<br>');
    }
    public function setComposers($composer){
        $this->composer = str_getcsv($composer);
    }
    public function getComposers(){
        for($j=0; $j<count($this->composer); $j++){
            print_r("Composer #".($j+1)." is ".$this->composer[$j]."<br>");
        }
    }


    public function setData($data_row){
      print_r('in set data function');

        $this->setArtist($data_row[0]);
        $this->setTitle($data_row[1]);
        $this->setAlbum($data_row[2]);
        $this->setYear($data_row[3]);
        $this->setGenre($data_row[4]);
        $this->setSubgenres($data_row[5]);
        $this->setComposers($data_row[6]);
        $this->setImageName($data_row[7]);

    }


    public function getData(){
        $this->getArtist();
        $this->getTitle();
        $this->getAlbum();
        $this->getYear();
        $this->getGenre();
        $this->getSubgenres();
        $this->getComposers();
        $this->getImageName();

    }

    public function save(){
      print_r('in save function');
        global $pdo;

        try{
          // print_r('try '.$this->genre);
            $album_insert = $pdo->prepare("INSERT INTO album (artist, title, album, year, sub_genre, composer, image_name)
                                            VALUES (?, ?, ?, ?, ?, ?, ?)");
            $db_album = $album_insert->execute([$this->artist, $this->title, $this->album, $this->year, implode(',', $this->sub_genre), implode(',', $this->composer), $this->image_name]);
            $this->id = $pdo->lastInsertId();
            print_r("--Saved $this->album to the database.--<br>\n");

            $select_genre = $pdo->prepare("SELECT * FROM genre WHERE name = ?");
            $genre_insert = $pdo->prepare("INSERT INTO genre (name) VALUES (?)");
            $genre_link = $pdo->prepare("INSERT INTO album_genre (album_id, genre_id) VALUES (?, ?)");
            for($i=0; $i<count($this->genre); $i++){
                $select_genre->execute([$this->genre[$i]]);
                $existing_genre = $select_genre->fetch();
                if(!$existing_genre){
                    $db_genre = $genre_insert->execute([$this->genre[$i]]);
                    $genre_id = $pdo->lastInsertID();
                } else {
                    $genre_id = $existing_genre['id'];
                }
                $genre_link->execute([$this->id, $genre_id]);
                print_r("Connected ".$this->genre[$i]." to $this->album<br>\n");
            }
            flush();
            ob_flush();
        } catch (PDOException $e){
            print_r("The Cake is a Lie: ".$e->getMessage() . "<br>\n");
            exit;
        }
    }

    static public function load_by_id($id){
        global $pdo;

        try{
            $find_album = $pdo->prepare("SELECT * FROM album
                                            WHERE id = ?");
            $select_genre = $pdo->prepare("SELECT genre.name AS name
                                                FROM album_genre, genre
                                                WHERE album_genre.album_id = ?
                                                AND album_genre.genre_id = genre.id");
            $find_album->execute([$id]);
            $db_album = $find_album->fetch();
            if(!$db_album){
                return false;
            } else {
                $album = new Album();
                $album->setArtist($db_album['artist']);
                $album->setTitle($db_album['title']);
                $album->setAlbum($db_album['album']);
                $album->setYear($db_album['year']);
                $album->setSubgenres($db_album['sub_genre']);
                $album->setComposers($db_album['composer']);
                $album->setImageName($db_album['image_name']);
                $album->setID($id);



                $select_genre->execute([$id]);
                $db_genres = $select_genre->fetchAll();
                $genres = array();
                for($j=0; $j<count($db_genres); $j++){
                    array_push($genres, $db_genres[$j]['name']);
                }
                $album->setGenre(implode(',', $genres));
                return $album;
            }
        } catch (PDOException $e){
            print_r("The pie has been burnt: ".$e->getMessage() . "<br>\n");
            exit;
        }
    }

    static public function load($genre=false){
        global $pdo;

        $albums = array();
        try{
            if($genre==false){
                $select_albums = $pdo->prepare("SELECT * FROM album ORDER BY artist ASC");
                $select_albums->execute();
            } else {
                $select_albums = $pdo->prepare("SELECT album.* FROM album, album_genre, genre
                                                WHERE album.id = album_genre.album_id AND
                                                  album_genre.genre_id = genre.id AND
                                                  genre.name = ?
                                                ORDER BY album.artist ASC");
                $select_albums->execute([$genre]);
            }

            $select_genre = $pdo->prepare("SELECT genre.name AS name
                                            FROM album_genre, genre
                                            WHERE album_genre.album_id = ?
                                              AND album_genre.genre_id = genre.id");


            $db_albums = $select_albums->fetchAll();

            for($i=0; $i<count($db_albums); $i++){
                $album = new Album();
                $album->setArtist($db_albums[$i]['artist']);
                $album->setTitle($db_albums[$i]['title']);
                $album->setAlbum($db_albums[$i]['album']);
                $album->setYear($db_albums[$i]['year']);
                $album->setSubgenres($db_albums[$i]['sub_genre']);
                $album->setComposers($db_albums[$i]['composer']);
                $album->setImageName($db_albums[$i]['image_name']);


                $album->setID($db_albums[$i]['id']);

                $select_genre->execute([$album->id]);
                $db_genres = $select_genre->fetchAll();
                $genres = array();
                for($j=0; $j<count($db_genres); $j++){
                    array_push($genres, $db_genres[$j]['name']);
                }
                $album->setGenre(implode(',', $genres));
                array_push($albums, $album);
            }
            return $albums;
        } catch (PDOException $e){
            print_r("Leeroy Jenkins: ".$e->getMessage() . "<br>\n");
            exit;
        }
    }
}
?>
